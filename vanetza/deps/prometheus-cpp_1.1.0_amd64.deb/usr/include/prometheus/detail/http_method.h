#pragma once

namespace prometheus {
namespace detail {
enum class HttpMethod {
  Post,
  Put,
  Delete,
};

}  // namespace detail
}  // namespace prometheus
